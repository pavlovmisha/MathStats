"""
RAG-система по Дискретной Математике (Теория графов)
Без LLM — использует TF-IDF + cosine similarity для поиска
"""

import os
import re
import json
import random
from flask import Flask, request, jsonify
from flask_cors import CORS

from retriever import Retriever
from trainer import Trainer

app = Flask(__name__)
CORS(app)

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

retriever = Retriever(
    chapter_path=os.path.join(DATA_DIR, "chapter.md"),
    terms_path=os.path.join(DATA_DIR, "terms.txt"),
)
trainer = Trainer(retriever)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "chunks": len(retriever.chunks)})


@app.route("/ask", methods=["POST"])
def ask():
    """Режим чата: студент задаёт вопрос, получает ответ из учебника."""
    data = request.get_json()
    question = data.get("question", "").strip()
    if not question:
        return jsonify({"error": "Вопрос не может быть пустым"}), 400

    results = retriever.search(question, top_k=3)
    if not results:
        return jsonify({"answer": "Не удалось найти релевантный фрагмент в учебнике.", "sources": []})

    best = results[0]
    answer = best["text"]
    score = best["score"]

    return jsonify({
        "answer": answer,
        "score": round(score, 3),
        "sources": [{"text": r["text"][:200] + "...", "score": round(r["score"], 3)} for r in results],
    })


@app.route("/trainer/question", methods=["GET"])
def get_question():
    """Тренажёр: получить случайный вопрос по терминологии."""
    term = request.args.get("term")
    q = trainer.get_question(term)
    return jsonify(q)


@app.route("/trainer/check", methods=["POST"])
def check_answer():
    """Тренажёр: проверить ответ студента."""
    data = request.get_json()
    term = data.get("term", "")
    student_answer = data.get("answer", "").strip()

    result = trainer.check(term, student_answer)
    return jsonify(result)


@app.route("/terms", methods=["GET"])
def list_terms():
    return jsonify({"terms": retriever.terms})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
