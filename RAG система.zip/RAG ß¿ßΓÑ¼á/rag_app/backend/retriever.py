"""
Retriever — TF-IDF поиск по чанкам учебника.
Без LLM, без внешних API. Только sklearn + nltk.
"""

import re
import math
import pickle
import os
from typing import List, Dict

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def split_into_chunks(text: str, min_len: int = 100, max_len: int = 600) -> List[str]:
    """
    Разбиваем текст на смысловые чанки.
    Сначала по абзацам, потом дробим длинные.
    """
    # Убираем лишние пробелы и форматирование Markdown
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'#+\s', '', text)  # убрать заголовки ##
    text = re.sub(r'\*+', '', text)

    paragraphs = text.split('\n\n')
    chunks = []

    for para in paragraphs:
        para = para.strip()
        para = re.sub(r'\s+', ' ', para)
        if len(para) < min_len:
            continue

        if len(para) <= max_len:
            chunks.append(para)
        else:
            # Дробим по предложениям
            sentences = re.split(r'(?<=[.!?])\s+', para)
            current = ""
            for sent in sentences:
                if len(current) + len(sent) <= max_len:
                    current = (current + " " + sent).strip()
                else:
                    if current:
                        chunks.append(current)
                    current = sent
            if current:
                chunks.append(current)

    return chunks


class Retriever:
    def __init__(self, chapter_path: str, terms_path: str):
        # Загружаем текст
        with open(chapter_path, "r", encoding="utf-8") as f:
            raw_text = f.read()

        # Загружаем термины
        with open(terms_path, "r", encoding="utf-8") as f:
            self.terms = [line.strip() for line in f if line.strip()]

        # Чанкуем текст
        self.chunks = split_into_chunks(raw_text)
        print(f"[Retriever] Загружено {len(self.chunks)} чанков из {len(raw_text)} символов")

        # TF-IDF векторизатор с поддержкой русского (ngrams для морфологии)
        self.vectorizer = TfidfVectorizer(
            analyzer="word",
            ngram_range=(1, 2),
            min_df=1,
            sublinear_tf=True,
            # Базовая "морфология" через подстроки
        )
        self.chunk_vectors = self.vectorizer.fit_transform(self.chunks)
        print(f"[Retriever] TF-IDF матрица: {self.chunk_vectors.shape}")

        # Строим индекс терминов: термин -> лучший чанк
        self._build_term_index()

    def _build_term_index(self):
        """Для каждого термина находим лучший объясняющий чанк."""
        self.term_index: Dict[str, Dict] = {}
        for term in self.terms:
            results = self.search(f"что такое {term} определение", top_k=1)
            if results:
                self.term_index[term] = results[0]
        print(f"[Retriever] Индекс терминов: {len(self.term_index)} записей")

    def search(self, query: str, top_k: int = 3) -> List[Dict]:
        """Поиск top_k наиболее релевантных чанков."""
        query_vec = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vec, self.chunk_vectors)[0]

        top_indices = np.argsort(scores)[::-1][:top_k]
        results = []
        for idx in top_indices:
            if scores[idx] > 0.01:  # Минимальный порог
                results.append({
                    "text": self.chunks[idx],
                    "score": float(scores[idx]),
                    "chunk_id": int(idx),
                })
        return results

    def get_term_context(self, term: str) -> str:
        """Получить контекст для конкретного термина."""
        if term in self.term_index:
            return self.term_index[term]["text"]
        # Fallback: прямой поиск
        results = self.search(term, top_k=1)
        return results[0]["text"] if results else f"Термин '{term}' не найден в учебнике."
