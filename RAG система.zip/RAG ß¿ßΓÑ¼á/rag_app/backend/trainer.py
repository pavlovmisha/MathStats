"""
Тренажёр — генерирует вопросы по терминам и валидирует ответы студента.
Без LLM. Вопросы: шаблонные. Валидация: TF-IDF косинусное сходство.
"""

import random
import re
from typing import Dict, Optional


QUESTION_TEMPLATES = [
    "Что такое {term}?",
    "Дайте определение понятию «{term}».",
    "Объясните, что понимается под {term} в теории графов.",
    "Чем отличается {term} от смежных понятий?",
]


class Trainer:
    def __init__(self, retriever):
        self.retriever = retriever
        self._current_questions: Dict[str, Dict] = {}

    def get_question(self, term: Optional[str] = None) -> Dict:
        """Сгенерировать вопрос. Если term не указан — случайный термин."""
        if not term:
            term = random.choice(self.retriever.terms)

        template = random.choice(QUESTION_TEMPLATES)
        question_text = template.format(term=term.lower())

        # Получаем эталонный ответ из учебника
        reference = self.retriever.get_term_context(term)

        # Кэшируем для последующей проверки
        self._current_questions[term] = {
            "reference": reference,
            "term": term,
        }

        return {
            "term": term,
            "question": question_text,
            "hint": f"Подсказка: найдите определение в разделе про {term.lower()}.",
        }

    def check(self, term: str, student_answer: str) -> Dict:
        """
        Валидация ответа студента.
        Используем TF-IDF косинусное сходство с эталонным фрагментом.
        Порог принятия: 0.15 (низкий — студент своими словами).
        """
        if not student_answer:
            return {
                "correct": False,
                "score": 0.0,
                "explanation": "Ответ пустой.",
                "reference": self._get_reference(term),
            }

        reference = self._get_reference(term)

        # Векторизуем оба текста через уже обученный векторизатор
        try:
            from sklearn.metrics.pairwise import cosine_similarity
            vecs = self.retriever.vectorizer.transform([student_answer, reference])
            score = float(cosine_similarity(vecs[0], vecs[1])[0][0])
        except Exception as e:
            score = 0.0

        # Также проверяем ключевые слова из термина
        term_words = set(term.lower().split())
        answer_words = set(student_answer.lower().split())
        keyword_match = len(term_words & answer_words) / max(len(term_words), 1)

        # Итоговый балл
        final_score = 0.6 * score + 0.4 * keyword_match
        correct = final_score >= 0.10  # мягкий порог — своими словами

        if correct:
            feedback = f"✅ Верно! Ваш ответ засчитан (сходство: {final_score:.0%})."
            explanation = None
        else:
            feedback = f"❌ Ответ не засчитан (сходство: {final_score:.0%})."
            # Находим предложение с определением из учебника
            explanation = self._extract_definition_sentence(term, reference)

        return {
            "correct": correct,
            "score": round(final_score, 3),
            "feedback": feedback,
            "explanation": explanation,
            "reference_snippet": reference[:400] + "..." if len(reference) > 400 else reference,
        }

    def _get_reference(self, term: str) -> str:
        if term in self._current_questions:
            return self._current_questions[term]["reference"]
        return self.retriever.get_term_context(term)

    def _extract_definition_sentence(self, term: str, context: str) -> str:
        """Найти предложение с определением термина."""
        sentences = re.split(r'(?<=[.!?])\s+', context)
        term_lower = term.lower()

        # Ищем предложение, содержащее термин
        for sent in sentences:
            if term_lower in sent.lower() and ("называется" in sent or "определяется" in sent
                                               or "— это" in sent or "это " in sent
                                               or "Def" in sent):
                return sent

        # Fallback — первое предложение с термином
        for sent in sentences:
            if term_lower in sent.lower():
                return sent

        return sentences[0] if sentences else context[:200]
