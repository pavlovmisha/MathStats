"""
serve.py — точка входа для Docker.
Flask раздаёт и API (/ask, /trainer/*) и статику (frontend/index.html).
"""

import sys
import os

# Добавляем backend в путь
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

from flask import Flask, send_from_directory
from flask_cors import CORS

from retriever import Retriever
from trainer import Trainer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')

app = Flask(__name__, static_folder=FRONTEND_DIR)
CORS(app)

retriever = Retriever(
    chapter_path=os.path.join(DATA_DIR, 'chapter.md'),
    terms_path=os.path.join(DATA_DIR, 'terms.txt'),
)
trainer = Trainer(retriever)


# ─── STATIC ──────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')


# ─── API ─────────────────────────────────────────────────
from flask import request, jsonify


@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'chunks': len(retriever.chunks)})


@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    question = data.get('question', '').strip()
    if not question:
        return jsonify({'error': 'Вопрос не может быть пустым'}), 400
    results = retriever.search(question, top_k=3)
    if not results:
        return jsonify({'answer': 'Не удалось найти релевантный фрагмент.', 'sources': []})
    best = results[0]
    return jsonify({
        'answer': best['text'],
        'score': round(best['score'], 3),
        'sources': [{'text': r['text'][:200] + '...', 'score': round(r['score'], 3)} for r in results],
    })


@app.route('/trainer/question')
def get_question():
    term = request.args.get('term')
    return jsonify(trainer.get_question(term))


@app.route('/trainer/check', methods=['POST'])
def check_answer():
    data = request.get_json()
    return jsonify(trainer.check(data.get('term', ''), data.get('answer', '')))


@app.route('/terms')
def list_terms():
    return jsonify({'terms': retriever.terms})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
